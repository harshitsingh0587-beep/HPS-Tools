export * from '../conversion/pptxService';
