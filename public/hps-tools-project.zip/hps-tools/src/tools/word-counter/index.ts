export * from './WordCounterTool';
